
Compilation:
	Make file has not been changed. It could run normally.
	Completed in 488 lab #gl32.

Manual:
	Complered all requirements.
	Extra:
		The triangle can be translate(move) by arror key.
		