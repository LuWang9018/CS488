
Compilation:
	Make file has not been changed. It could run normally. 
	Completed in 488 lab #gl28.


Manual:
	Completed all the requirements.

